<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                2019 © ePakan.id.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                    Onel Himalow
                </div>
            </div>
        </div>
    </div>
</footer>